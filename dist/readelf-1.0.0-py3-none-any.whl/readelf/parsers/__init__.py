from .section_parser import parse_content
