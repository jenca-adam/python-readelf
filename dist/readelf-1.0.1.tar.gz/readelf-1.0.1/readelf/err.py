class ParseError(ValueError):
    pass
